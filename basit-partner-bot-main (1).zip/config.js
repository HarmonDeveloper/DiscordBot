module.exports = {
    token: "MTA1NjU4OTY2MTIxODI4MzYwMQ.GrCxRS.Xy9gW5tVToInmhztmylsPDMkUkm0oyHhFpb8-MTA1NjU4OTY2MTIxODI4MzYwMQ.GpIRdP.ZGTMclWPtVcei32yrV8j76J2_GGHBRzZsEXOAk", 
    prefix: "-"
}

